//
// Created by yi on 4/8/19.
//

#ifndef RECTANGLE_SEARCH_EXCEPTION_H
#define RECTANGLE_SEARCH_EXCEPTION_H
#include <stdlib.h>
#include <iostream>
//check the number of the arguments
void CheckInputNum(int argc);
void CannotOpenFile(std::string filename);
#endif //RECTANGLE_SEARCH_EXCEPTION_H
